<?php
include "admin/php/config.php";
$ban = mysqli_query($conn, "SELECT * FROM banner ORDER BY id DESC LIMIT 1"  );
$st = mysqli_query($conn, "SELECT * FROM stat ORDER BY id DESC LIMIT 4"  );
$sp = mysqli_query($conn, "SELECT * FROM spek ORDER BY id DESC LIMIT 4"  );
$con = mysqli_query($conn, "SELECT * FROM conference ORDER BY id DESC LIMIT 15"  );
$contact = mysqli_query($conn, "SELECT * FROM contact ORDER BY id DESC LIMIT 1"  );
$gal = mysqli_query($conn, "SELECT * FROM gal ORDER BY id DESC LIMIT 10"  );
$ham = mysqli_query($conn, "SELECT * FROM hamkor ORDER BY id DESC LIMIT 10"  );
?>