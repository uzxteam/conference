<?php

  
  include "admin/php/config.php";
  if(isset($_GET['id'])){
    $id=$_GET['id'];
   
  $con = mysqli_query($conn, "SELECT * FROM conference  WHERE id = '$id' ");
  $con1 = mysqli_query($conn, "SELECT * FROM conference  WHERE id = '$id' ");
  $con2 = mysqli_query($conn, "SELECT * FROM conference  WHERE id = '$id' ");
  }
    
  
?>