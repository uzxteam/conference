(function($) {	
	'use strict';
        jQuery(function () {
            jQuery('#defaultCountdown').countdown({until: new Date(2022, 3, 11, 0)}); // year, month, date, hour
        });
})(jQuery);

