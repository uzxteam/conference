<!DOCTYPE html>
<html lang="zxx">
<head>
  <!-- ===================================== Meta site ================================================ -->
  <meta charset="utf-8">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <!-- ====== Laravel description site edit delete from admin panel ================== -->
  <meta name="description" content="Evanto is a Theme - Premium Multiple Event &amp; Conference Site script Template">
  <!-- ====== Laravel author site edit delete from admin panel ====================== -->
  <meta name="author" content="author">
  <!-- ====== Laravel keywords site edit delete from admin panel ================== -->
  <meta name="keywords" content="Evanto is a Theme - Premium Multiple Event &amp; Conference Site script Template">  
  <!-- ====== Laravel robots site edit delete from admin panel ================== -->
  <meta name="robots" content="Metarobots">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <!-- TWITTER META -->
  <meta name="twitter:card" content="summary">
  <meta name="twitter:site" content="@Event  management">
  <meta name="twitter:creator" content="@Event  management">
  <meta name="twitter:title" content="Event management">
  <meta name="twitter:description" content="Event management ">
  <!-- ====== Laravel favicon icon ================== -->
 
  <link rel="manifest" href="manifest.json">
  <!-- ====== SiteTitle ========================================================================== -->
  <title>Conference</title>
  <!-- ===========================================  googleapis =================================== -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,600&display=swap" rel="stylesheet">
  <!-- ===========================================  googleapis =================================== -->
  <link href="https://fonts.googleapis.com/css?family=Righteous&display=swap" rel="stylesheet">
  <!-- ===========================================  googleapis =================================== -->
  <link href="https://fonts.googleapis.com/css2?family=Lalezar&display=swap" rel="stylesheet">
    <!-- ===========================================  main =================================== -->
  <link rel="stylesheet" type="text/css" href="css/main.css" />
  <!-- ===========================================  uikit ============================== -->
  <script src="js/uikit.js"></script>
  <!-- ===========================================  uikit icons ============================== -->
  <script src="js/uikit-icons.js"></script> 
  <!-- ===========================================  head =================================== -->
  <span class="display-zero">en</span>
     
</head>
<body> 

<!-- ============================================================= Content Start =========================================== -->
<span class="display-zero">en</span>
<!-- ============================================================= content ================================================= -->

<div class="uk-section uk-light uk-background-cover" style="background-image: url('images/breadcrumbs-bg.jpg')">
  <div class="uk-container uk-container-xlarge">
<?php
  include "mor.php";

 
  while ($row = mysqli_fetch_array($con)) {
  
    echo "<h2 class='uk-heading-small uk-heading-bullet'>" . $row["nomi"] . "</h2> ";
    echo "<ul class='uk-breadcrumb'>";
        echo "<li class='uk-button uk-button-text'><a href='index.php'>Home</a></li>";
        echo "<li><span>" . $row["nomi"] . "</span></li>";
        echo "</ul>";
      
  }
?>

 

    
    
      
      
           
  </div>
</div>
<div class="uk-section uk-section-muted">
  <div class="uk-container uk-container-xlarge">
    <div data-uk-grid>
     <div class="uk-width-expand">
      <div class="uk-card uk-card-default uk-card-body uk-border-rounded">
        <div  uk-grid>
          <div class="uk-width-1-1">
            <article class="uk-article">
            <?php
while ($row = mysqli_fetch_array($con1)) {
  
    echo " <img class='uk-border-rounded' data-src='admin/images/" . $row["images"] . "' width='800' height='600'  alt='mart 18, 2022 16:00 am' uk-img>";
    echo "<p class='uk-article-meta'>Written by  <a><span uk-icon='icon: users'></span>  <a> " . $row["masul"] . " </a> </a> ";
        echo "<span uk-icon='icon: calendar'></span> " . $row["bosh"] . " </p> " . $row["matn"] . " ";
     
      
  }
?>

                           
                             
                            
                           <div class="uk-grid-small uk-child-width-auto uk-margin-small-top" uk-grid> </div>
          </article>
        </div>
       
      </div>
    </div>
  </div>
  <div class="uk-width-1-3@m">

 <div class="uk-card uk-card-default uk-card-body uk-border-rounded uk-margin-top">
   <div  uk-grid>
     <div class="uk-width-1-1">
      <h1 class="uk-heading-xsmall uk-margin-remove-top uk-heading-bullet">Event Details</h1>
    </div>
    <div class="uk-width-expand">
    <?php
while ($row = mysqli_fetch_array($con2)) {
  
    
    echo "<div class='uk-grid-medium uk-flex-middle' data-uk-grid>";
        echo " <div class='uk-width-auto'>";
     echo"<span uk-icon='icon: history; ratio: 2'></span>";
     echo"</div>";
     echo"<div class='uk-width-expand'>";
     echo"<h4 class='uk-comment-title uk-margin-remove'><a class=''-link-reset'>Start Date</a></h4>";
     echo"<p class='uk-comment-meta uk-margin-remove-top'><a class='uk-button-text'>" . $row["bosh"] . "</a></p>";
     echo"</div>";
     echo"</div>";



 
     echo "<div class='uk-grid-medium uk-flex-middle' data-uk-grid>";
         echo " <div class='uk-width-auto'>";
      echo" <span uk-icon='icon: future; ratio: 2'></span>";
      echo"</div>";
      echo"<div class='uk-width-expand'>";
      echo"<h4 class='uk-comment-title uk-margin-remove'><a class=''-link-reset'>End Date</a></h4>";
      echo"<p class='uk-comment-meta uk-margin-remove-top'><a class='uk-button-text'>" . $row["tug"] . "</a></p>";
      echo"</div>";
      echo"</div>";


      echo "<div class='uk-grid-medium uk-flex-middle' data-uk-grid>";
      echo " <div class='uk-width-auto'>";
   echo" <span uk-icon='icon: check; ratio: 2'></span>";
   echo"</div>";
   echo"<div class='uk-width-expand'>";
   echo"<h4 class='uk-comment-title uk-margin-remove'><a class=''-link-reset'>Status</a></h4>";
   echo"<p class='uk-comment-meta uk-margin-remove-top'><a class='uk-button-text'>" . $row["status"] . "</a></p>";
   echo"</div>";
   echo"</div>";
      
   echo "<div class='uk-grid-medium uk-flex-middle' data-uk-grid>";
   echo " <div class='uk-width-auto'>";
echo" <span uk-icon='icon: location; ratio: 2'></span>";
echo"</div>";
echo"<div class='uk-width-expand'>";
echo"<h4 class='uk-comment-title uk-margin-remove'><a class=''-link-reset'>Location</a></h4>";
echo"<p class='uk-comment-meta uk-margin-remove-top'><a class='uk-button-text'>" . $row["manzil"] . "</a></p>";
echo"</div>";
echo"</div>";



echo "<div class='uk-grid-medium uk-flex-middle' data-uk-grid>";
echo " <div class='uk-width-auto'>";
echo" <span uk-icon='icon: user; ratio: 2'></span>";
echo"</div>";
echo"<div class='uk-width-expand'>";
echo"<h4 class='uk-comment-title uk-margin-remove'><a class=''-link-reset'>Organizer</a></h4>";
echo"<p class='uk-comment-meta uk-margin-remove-top'><a class='uk-button-text'>" . $row["masul"] . "</a></p>";
echo"</div>";
echo"</div>";

echo "<div class='uk-grid-medium uk-flex-middle' data-uk-grid>";
echo " <div class='uk-width-auto'>";

echo"</div>";
echo"<div class='uk-width-expand'>";
echo"<h4 class='uk-comment-title uk-margin-remove'><a href='admin/fayl/" . $row["fayl"] . "' >Organizer</a></h4>";
echo"</div>";
echo"</div>";

  }
?>

      
     

    </div>
  </div>
</div>



</body>
</html>