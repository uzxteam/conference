-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Окт 04 2021 г., 07:26
-- Версия сервера: 8.0.24
-- Версия PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `uzxteam1`
--

-- --------------------------------------------------------

--
-- Структура таблицы `about`
--

CREATE TABLE `about` (
  `id` int NOT NULL,
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `haqida` text NOT NULL,
  `avzal` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `about`
--

INSERT INTO `about` (`id`, `images`, `haqida`, `avzal`) VALUES
(2, 'WIN_20210922_06_17_22_Pro.jpg', 'wqafdwqaf', 'wafwafwafgw');

-- --------------------------------------------------------

--
-- Структура таблицы `conf`
--

CREATE TABLE `conf` (
  `id` int NOT NULL,
  `nomi` text NOT NULL,
  `qisqacha` text NOT NULL,
  `manzili` text NOT NULL,
  `vaqti` text NOT NULL,
  `batafsil` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `conf`
--

INSERT INTO `conf` (`id`, `nomi`, `qisqacha`, `manzili`, `vaqti`, `batafsil`) VALUES
(5, 'ewwqrdf', 'wqfrwq', 'fwqfwq', 'fwqfwqf', 'wqfwqf');

-- --------------------------------------------------------

--
-- Структура таблицы `hamkor`
--

CREATE TABLE `hamkor` (
  `id` int NOT NULL,
  `images` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `hamkor`
--

INSERT INTO `hamkor` (`id`, `images`) VALUES
(5, 'Group 1 (1).png'),
(6, 'Group 1 (1).png');

-- --------------------------------------------------------

--
-- Структура таблицы `javob`
--

CREATE TABLE `javob` (
  `id` int NOT NULL,
  `savol` text NOT NULL,
  `javob` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `javob`
--

INSERT INTO `javob` (`id`, `savol`, `javob`) VALUES
(2, 'wwqadfw', 'wqdwqdwq');

-- --------------------------------------------------------

--
-- Структура таблицы `rasm`
--

CREATE TABLE `rasm` (
  `id` int NOT NULL,
  `images` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `rasm`
--

INSERT INTO `rasm` (`id`, `images`) VALUES
(11, 'WIN_20210922_06_17_22_Pro.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `unique_id` int NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`user_id`, `unique_id`, `fname`, `lname`, `email`, `password`, `img`, `status`) VALUES
(1, 1525673840, 'temur', 'malik', 'admin@andmbi.uz', '1ba2656880fb6cb03891142158433b39', '1633055872WIN_20210922_06_17_22_Pro.jpg', 'Active now');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `conf`
--
ALTER TABLE `conf`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `hamkor`
--
ALTER TABLE `hamkor`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `javob`
--
ALTER TABLE `javob`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rasm`
--
ALTER TABLE `rasm`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `about`
--
ALTER TABLE `about`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `conf`
--
ALTER TABLE `conf`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `hamkor`
--
ALTER TABLE `hamkor`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `javob`
--
ALTER TABLE `javob`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `rasm`
--
ALTER TABLE `rasm`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
