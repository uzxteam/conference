<?php
include "admin/php/config.php";

  $about = mysqli_query($conn, "SELECT * FROM about ORDER BY id DESC LIMIT 1"  );
  $conf= mysqli_query($conn, "SELECT * FROM conf ORDER BY id DESC LIMIT 1"  );
  $conff= mysqli_query($conn, "SELECT * FROM conf ORDER BY id DESC LIMIT 1"  );
  $confa= mysqli_query($conn, "SELECT * FROM conf ORDER BY id DESC LIMIT 3"  );
  $hamkor= mysqli_query($conn, "SELECT * FROM hamkor ORDER BY id DESC LIMIT 4"  );
  $javob= mysqli_query($conn, "SELECT * FROM javob ORDER BY id DESC LIMIT 7"  );
  $cof= mysqli_query($conn, "SELECT * FROM conf ORDER BY id DESC LIMIT 1"  );
?>