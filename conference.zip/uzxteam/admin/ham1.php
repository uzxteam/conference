<?php
include "php/config.php";

 
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['save'])) {
  	// Get image name
  	$image = $_FILES['rasm']['name'];
  
  
  	// image file directory
  	$target = "images/".basename($image);

  	$sql = "INSERT INTO hamkor (images) VALUES ('$image')";
  	// execute query
  	mysqli_query($conn, $sql);

  	if (move_uploaded_file($_FILES['rasm']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($conn, "SELECT * FROM hamkor ORDER BY id DESC LIMIT 3"  );
  header('Location:hamkor.php');
?>