<?php 
   include "php/config.php";
  if(isset($_GET['id'])){
    $id=$_GET['id'];
    $sql = mysqli_query($conn, "DELETE FROM about WHERE id = '$id'");
    header ("Location: about.php");
  }
 
  if(isset($_GET['idd'])){
    $id=$_GET['idd'];
    $sql = mysqli_query($conn, "DELETE FROM rasm WHERE id = '$id'");
    header("Location: uzx.php");
  }

  if(isset($_GET['hamkor'])){
    $id=$_GET['hamkor'];
    $sql = mysqli_query($conn, "DELETE FROM hamkor WHERE id = '$id'");
    header("Location: hamkor.php");
  }



  if(isset($_GET['savol'])){
    $id=$_GET['savol'];
    $sql = mysqli_query($conn, "DELETE FROM javob WHERE id = '$id'");
    header("Location: javob.php");
  }

  if(isset($_GET['ide'])){
    $id=$_GET['ide'];
    $sql = mysqli_query($conn, "DELETE FROM conf WHERE id = '$id'");
    header ("Location: conferens.php");
  }?>