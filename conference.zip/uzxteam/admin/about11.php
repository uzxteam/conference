<?php
include "php/config.php";

  $msg = "";

  if (isset($_POST['save'])) {
  
  	$image = $_FILES['rasm']['name'];
      $haqida = mysqli_real_escape_string($conn, $_POST['haqida']);
      $avzal = mysqli_real_escape_string($conn, $_POST['avzal']);
  
  	$target = "images/".basename($image);

  	$sql = "INSERT INTO about (images,haqida,avzal) VALUES ('$image','$haqida','$avzal')";
 
  	mysqli_query($conn, $sql);

  	if (move_uploaded_file($_FILES['rasm']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  $result = mysqli_query($conn, "SELECT * FROM about ORDER BY id DESC LIMIT 3"  );
  header('Location:about.php');
?>