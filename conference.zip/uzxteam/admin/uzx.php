<?php
include "menu.php"; ?>
	<?php
include "banner1.php"; ?>
		
		<div class="page-wrapper">
			<div class="page-content">
				<div class="row row-cols-1 row-cols-md-2 row-cols-xl-4">
                   <div class="col">
					 <div class="card radius-10 border-start border-0 border-3 border-info">
						<div class="card-body">
							<div class="d-flex align-items-center">
								<div> <?php
    while ($row = mysqli_fetch_array($result)) {
    
      	echo "<img width='200px'  src='images/".$row['images']."' >";
      echo "	<a type='button' class='btn btn-outline-danger px-5 radius-30' href='dele.php?idd=" . $row["id"] . "'>ochirish<a/> ";
      
    }
  ?>
								
								</div>
								
							</div>
						</div>
					 </div>
				   </div>
				  
				  </div> 
				</div><!--end row-->

			

			</div>
		</div>
		<?php
include "pasi.php"; ?>