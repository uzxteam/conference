<?php
include "php/config.php";

  $msg = "";

  if (isset($_POST['save'])) {
  
      $nomi = mysqli_real_escape_string($conn, $_POST['savol']);
      $haqida = mysqli_real_escape_string($conn, $_POST['javob']);
    


  	$sql = "INSERT INTO javob (savol,javob) VALUES ('$nomi','$haqida')";
 
  	mysqli_query($conn, $sql);

     
  }
  $result = mysqli_query($conn, "SELECT * FROM javob ORDER BY id DESC LIMIT 9"  );
  header('Location:javob.php');
?>