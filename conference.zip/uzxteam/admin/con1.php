<?php
include "php/config.php";

  $msg = "";

  if (isset($_POST['save'])) {
  
      $nomi = mysqli_real_escape_string($conn, $_POST['nomi']);
      $haqida = mysqli_real_escape_string($conn, $_POST['qisqacha']);
      $manzil = mysqli_real_escape_string($conn, $_POST['manzili']);
      $vaqti = mysqli_real_escape_string($conn, $_POST['vaqti']); 
      $batafsil = mysqli_real_escape_string($conn, $_POST['batafsil']);


  	$sql = "INSERT INTO conf (nomi,qisqacha,manzili,vaqti,batafsil) VALUES ('$nomi','$haqida','$manzil','$vaqti','$batafsil')";
 
  	mysqli_query($conn, $sql);

  
  }
  $result = mysqli_query($conn, "SELECT * FROM conf ORDER BY id DESC LIMIT 9"  );
  header('Location:conferens.php');
?>