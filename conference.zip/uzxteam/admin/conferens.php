<?php
include "menu.php"; ?>
	<?php
include "con1.php"; ?>
		<div class="page-wrapper">
			<div class="page-content">
				
			
				<h6 class="mb-0 text-uppercase">Conferens</h6>
				<hr/>
				<div class="row row-cols-1 row-cols-md-1 row-cols-lg-3 row-cols-xl-3">

				<?php
    while ($row = mysqli_fetch_array($result)) {
    
      	echo "<div class='col'>";
		  echo "<div class='card'>";
		  echo "<div class='card-body'>";
		  echo "<h5 class='card-title'>".$row['nomi']."</h5>";
		  echo "<p class='card-text'>".$row['qisqacha']."</p>";
		  echo "</div>";
		  echo "<ul class='list-group list-group-flush'>";
		  echo "<li class='list-group-item'>".$row['manzili']."</li>";
		  echo "<li class='list-group-item'>".$row['vaqti']."</li>";
		  echo "</ul>";
		  echo "	<a type='button' class='btn btn-outline-danger px-5 radius-30' href='dele.php?ide=" . $row["id"] . "'>ochirish<a/> ";
		  echo "</div>";
		  echo "</div>";


		 
    
      
    }
  ?>

								
						
					
					
				</div>
				
				<!--end row-->
			</div>
		</div>
		<!--end page wrapper -->
		<!--start overlay-->
		<?php
include "pasi.php"; ?>