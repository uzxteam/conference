<?php
include "menu.php"; ?>
	
		<div class="page-wrapper">
			<div class="page-content">
				
			
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase">O'zgartirish</h6>
						<hr/>
						<div class="card">
							<div class="card-body">
                            <form method="POST" action="savol1.php" enctype="multipart/form-data">
									
                                    <input class="form-control form-control-lg mb-3" name="savol" placeholder="Savol" aria-label=".form-control-lg example">
									<input class="form-control form-control-lg mb-3" name="javob" placeholder="Javob" aria-label=".form-control-lg example">
      <div>
      
                                    <button type="submit" name="save" class="btn btn-outline-dark px-5"><i class='bx bx-cloud-upload mr-1'></i>Saqlash</button>
								</form> 	
  	<div>
     </div>
  
							</div>
						</div>
					</div>
				</div>
	
  	
  	
			</div>
		</div>
		<!--end page wrapper -->
		<!--start overlay-->
        <?php
include "pasi.php"; ?>