<?php
include "menu.php"; ?>
	
		<div class="page-wrapper">
			<div class="page-content">
				
			
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase">O'zgartirish</h6>
						<hr/>
						<div class="card">
							<div class="card-body">
                            <form method="POST" action="about11.php" enctype="multipart/form-data">
									<input  type="file" name="rasm" accept=".xlsx,.xls,image/*,.doc,audio/*,.docx,video/*,.ppt,.pptx,.txt,.pdf" multiple>
                                    <div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="haqida" 
      	placeholder="Conferensiya haqida..."></textarea>
  	</div>
      <div>
      <textarea 
      	id="text" 
      	cols="40" 
      	rows="4" 
      	name="avzal" 
      	placeholder="Malumotlar..."></textarea>
  	</div>
                                    <button type="submit" name="save" class="btn btn-outline-dark px-5"><i class='bx bx-cloud-upload mr-1'></i>Upload</button>
								</form> 	
  	<div>
     </div>
  
							</div>
						</div>
					</div>
				</div>
	
  	
  	
			</div>
		</div>
		<?php
include "pasi.php"; ?>