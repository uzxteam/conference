<?php
include "menu.php"; ?>
		
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				
			
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase">Rasm yuklash</h6>
						<hr/>
						<div class="card">
							<div class="card-body">
								<form method="POST" action="ham1.php" enctype="multipart/form-data">
									<input  type="file" name="rasm" accept=".xlsx,.xls,image/*,.doc,audio/*,.docx,video/*,.ppt,.pptx,.txt,.pdf" multiple>
								    <button type="submit" name="save" class="btn btn-outline-dark px-5"><i class='bx bx-cloud-upload mr-1'></i>Upload</button>
								</form> 
							</div>
						</div>
					</div>
				</div>
	
  	
  	
			</div>
		</div>
		<!--end page wrapper -->
		<!--start overlay-->
		
    <?php
include "pasi.php"; ?>