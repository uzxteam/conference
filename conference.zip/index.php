<?php
include "uzx.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Conference - Andmbi</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Invitex is event and conference website template">
    <meta name="author" content="">

    <!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<![endif]-->

    <!-- CSS Files
    ================================================== -->
    <link rel="stylesheet" href="css/bootstrap.css" type="text/css">
    <link rel="stylesheet" href="css/animate.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.css" type="text/css">
    <link rel="stylesheet" href="css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="css/jquery.countdown.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="css/color.css" type="text/css">
	<link rel="stylesheet" href="css/colors/orange.css" type="text/css">
    <link rel="stylesheet" href="css/colors/gradient-1.css" type="text/css">

    <!-- background -->
    <link rel="stylesheet" href="css/bg.css" type="text/css">
</head>

<body id="homepage">

    <div id="wrapper">

        <!-- header begin -->
        <header>

            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <!-- logo begin -->
                       
                        <!-- logo close -->

                        <!-- small button begin -->
                    <span id="menu-btn"></span>
                        <!-- small button close -->

                        <!-- mainmenu begin -->
                        <nav>
                            <ul id="mainmenu">
                                <li><a class="active" href="#top">Home</a></li>
                                <li><a href="#section-about">About</a></li>
                                <li><a href="#section-speakers">Speakers</a></li>
                                <li><a href="#section-schedules">Conference</a></li>
                               
                                <li><a href="#section-register">Register</a></li>								
								<li><a href="#section-gallery">Gallery</a></li>
                                <li><a href="#section-sponsors">Sponsors</a></li>
                            </ul>
                        </nav>

                    </div>
                    <!-- mainmenu close -->

                </div>
            </div>
        </header>
        <!-- header close -->

        <!-- content begin -->
        <div id="content" class="no-bottom no-top">
            <div id="top"></div>

            <!-- section begin -->
            <section id="section-intro" class="full-height relative owl-slide-wrapper no-top no-bottom text-white" data-stellar-background-ratio=".2">
                <div class="overlay-gradient">

                   
                <?php
    while ($row = mysqli_fetch_array($ban)) {
    
    	echo "  <div id='custom-owl-slider' class='owl-slide' data-scroll-speed='10'>";
		  echo "<div class='item'>";
          echo " <img alt='' class='img-responsive' src='admin/images/" . $row["images"] . "'>";
          echo "</div>";
   
      
    }
  ?>
                       
                    </div>

                    <div class="center-y relative">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-6">
									<div class="spacer-half sm-hide"></div>
                                    <div class="spacer-double sm-hide"></div>
                                    <h1 class="big"><br>Conference.</h1>
                                    <div class="spacer-single"></div>
                                    <div class="subtitle s2"><span><i class="fa fa-map-marker orange"></i>Andijan</span></div>
                                </div>

                                <div class="col-md-6 text-center">
                                    <div class="inline-block md-float-right">
                                        <div class="spacer-single sm-hide"></div>
                                        <div class="spacer-double"></div>
                                        <div class="subtitle s3 mb20">Event Begin In</div>
                                        <div id="defaultCountdown" class="countdown-s1"></div>
                                        <div class="spacer-single"></div>
                                        <div class="clearfix"></div>
                                        <a href="conference.docx" class="btn-custom scroll-to">INFORMATION LETTER</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-about">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h2 class="wow fadeInUp">INFORMATION LETTER</h2>
                            <div class="small-border wow fadeInUp" data-wow-delay=".2s"></div>
                        </div>
                        <div class="col-md-6 col-md-offset-3 text-center">
                            <p class="lead wow fadeInUp">In accordance with Annex 1 to the  Order of the Cabinet of Ministers of the Republic of Uzbekistan No. 101-F dated March 7, 2022, “Plan of international scientific and scientific-technical activities in 2022”,  the international scientific-practical conference "The role and importance of digital life and social sciences in the upbringing of a harmoniously developed generation: current problems and prospects" will be held on April 11-12, 2022 at the Andijan Machine Building Institute”. </p>
                            <div class="spacer-single"></div>
                        </div>

                        <div class="col-md-4 text-center wow fadeInLeft">
                            <div class="padding20 sm-mb30">
                                <i class="icon-profile-male mb20 size70 orange"></i>
                                <h3>Ask The Experts</h3>
                                <p>Phone number: +998991775522<br> Telegram: +998991775522<br>E-mail khondam18@gmail.com
</p>
                            </div>
                        </div>

                        <div class="col-md-4 text-center wow fadeInUp">
                            <div class="padding20 sm-mb30">
                                <i class="icon-presentation mb20 size70 pink"></i>
                                <h3>Mas'uliyatli </h3>
                                <p>Head of the Department of "Humanities" - I.M. Sirojiddinova<br>Professor K. Muftayidinov<br> Head of the Department of “Uzbek language and Literature”  - H.M. Jurabekova
</p>
                            </div>
                        </div>

                        <div class="col-md-4 text-center wow fadeInRight">
                            <div class="padding20 sm-mb30">
                                <i class="icon-desktop mb20 size70 purple"></i>
                                <h3>Workshops</h3>
                                <p>There are many hotels available around the event location for temporary residence as long as you follow this event, from motels to 5 stars.</p>
                            </div>
                        </div>

                    </div>
                </div>
            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-fun-facts" class="no-top no-bottom text-light" data-stellar-background-ratio=".2">
                <div class="overlay-gradient pt80 pb80">
                    <div class="container">

                        <div class="row">
                        <?php
    while ($row = mysqli_fetch_array($st)) {
    
    	echo "<div class='col-md-3 col-xs-6 wow fadeIn'>";
		  echo " <div class='de_count sm-mb30'>";
          echo "<h3 class='timer' data-to='" . $row["raqam"] . "' data-speed='2500'>" . $row["raqam"] . "</h3>";
          echo " <span>" . $row["uzx"] . "</span>";
          echo "</div>";
          echo "</div>";
   
      
    }
  ?>
                            
                               
                                    
                                   
                            
                           
                        </div>
                    </div>
                </div>
            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-speakers">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h2 class="wow fadeInUp">Meet The Speakers</h2>
                            <div class="small-border wow fadeInUp" data-wow-delay=".2s"></div>
                        </div>
                        <div class="col-md-6 col-md-offset-3 text-center">
                            <p class="lead wow fadeInUp">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae.</p>
                            <div class="spacer-single"></div>
                        </div>

                        <div class="clearfix"></div>

                    
                        <?php
    while ($row = mysqli_fetch_array($sp)) {
    
    	echo "<div class='col-md-3 wow fadeIn' data-wow-delay='.2s'>";
		  echo "<div class='profile_pic text-center sm-mb30'>";
          echo "<figure class='picframe s2 mb30'>";
          echo " <a class='simple-ajax-popup' href='more.php?id=" . $row["id"] . "'>";
          echo " <span class='filter'></span>";
          echo "</a>";
          echo "<img src='admin/images/" . $row["images"] . "' class='img-responsive' alt=''>";
          echo "</figure>";
          echo "<h3>" . $row["ismi"] . "</h3>";
          echo "<span class='subtitle'>" . $row["lavozim"] . "</span>";
          echo "</div>";
          echo "</div>";
   
      
    }
  ?>
            

                    </div>
                </div>
            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-schedules" class="no-top no-bottom text-light" data-stellar-background-ratio=".2">
                <div class="overlay-gradient pt80 pb80">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h2 class="wow fadeInUp">Conference</h2>
                                <div class="small-border wow fadeInUp" data-wow-delay=".2s"></div>
                            </div>
                            <div class="col-md-6 col-md-offset-3 text-center">
                                  <div class="spacer-single"></div>
                            </div>

                            <div class="col-md-12 wow fadeInUp">
                                <div class="de_tab tab_style_4 text-center">
                                  

                                    <div class="de_tab_content text-left">

                                        <div id="tab1" class="tab_single_content">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    
                        <?php
    while ($row = mysqli_fetch_array($con)) {
    
    	echo "<div class='schedule-listing'>";
		  echo " <div class='schedule-item'>";
         
        
          echo "<div class='sc-pic'>";
          echo "<img src='admin/images/" . $row["images"] . "' class='img-circle' alt=''>";
          echo "</div>";
          echo "<div class='sc-name'>";
          echo " <h4>" . $row["masul"] . "</h4>";
          echo "<span>" . $row["manzil"] . "</span>";
          echo "</div>";
          echo " <div class='sc-info'>";
          echo " <h3>" . $row["nomi"] . "</h3> <a href='more.php?id=" . $row["id"] . "' class='btn-custom scroll-to'>More</a>";
          echo "</div>";
          echo " <div class='clearfix'></div>";
          echo "</div>";
          echo "</div>";
    }
  ?>
                                                    
                                                       
                                             

                                                   
                                                </div>
                                            </div>
                                        </div>

                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- section close -->

       
           

            <!-- section begin -->
            <section id="section-register" class="no-top no-bottom text-light" data-stellar-background-ratio=".2">
                <div class="overlay-gradient pt80 pb80">
                    <div class="container">

                        <div class="row">
                            <div class="col-md-12 text-center">
                                <h2 class="wow fadeInUp">Register</h2>
                                <div class="small-border wow fadeInUp" data-wow-delay=".2s"></div>
                            </div>
                            <div class="col-md-6 col-md-offset-3 text-center">
                                  <div class="spacer-single"></div>
                            </div>
                        </div>

                        

                        <div class="spacer-double"></div>

                        <div class="row text-center">

                
                        <?php
    while ($row = mysqli_fetch_array($contact)) {
    
    	 
		  echo "<div class='col-md-4'>";
          echo "<div class='wm-1'></div>";
          echo " <i class='icon-map id-color size40 mb20'></i>";
          echo "<h5>Address</h5>";
          echo "<h4>" . $row["manzil"] . "</h4>";
          echo "</div>";

          echo "<div class='col-md-4'>";
          echo "<div class='wm-1'></div>";
          echo "  <i class='icon-phone id-color size40 mb20'></i>";
          echo "<h5>Call Us</h5>";
          echo " <h4>" . $row["nomer"] . "</h4>";
          echo "</div>";

          echo "<div class='col-md-4'>";
          echo "<div class='wm-1'></div>";
          echo " <i class='icon-envelope id-color size40 mb20'></i>";
          echo "<h5>Email Us</h5>";
          echo "<h4>" . $row["email"] . "</h4>";
          echo "</div>";
        
    }
  ?>


                        </div>

                    </div>
                </div>

            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-gallery">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <h2 class="wow fadeInUp">Gallery</h2>
                            <div class="small-border wow fadeInUp" data-wow-delay=".2s"></div>
                        </div>
                        <div class="col-md-6 col-md-offset-3 text-center">
                                    <div class="spacer-single"></div>
                        </div>

                        <div class="clearfix"></div>

                        <div id="owl-gallery" class="owl-carousel wow fadeInUp">

                        <?php
    while ($row = mysqli_fetch_array($gal)) {




                          echo"<div class='gallery-item text-center'>";
                          echo"<figure class='picframe s2 mb30'>";
                          echo"<a class='image-popup' href='images/gallery/1.jpg'>";
                          echo"<span class='filter'></span>";
                          echo"</a>";
                          echo"<img src='admin/images/" . $row["images"] . "' class='img-responsive' alt=''>";
                          echo"</figure>";
                          echo"</div>";
    }   ?>
                            
                        </div>

                    </div>
                </div>
            </section>
            <!-- section close -->

            <!-- section begin -->
            <section id="section-sponsors" class="no-top no-bottom text-light" data-stellar-background-ratio=".2">
                <div class="overlay-gradient pt80 pb80">
                    <div class="container relative">
                        <div class="row">
                            <div class="row">
                                <div class="col-md-12 text-center">
                                    <h2 class="wow fadeInUp">Sponsors</h2>
                                    <div class="small-border wow fadeInUp" data-wow-delay=".2s"></div>
                                    <div class="spacer-single"></div>
                                </div>
                                

                                <div class="col-md-12 text-center wow fadeInUp">
                                    <div class="owl-carousel owl-sponsors ">

                                    <?php
    while ($row = mysqli_fetch_array($ham)) {




                      
                          echo"  <div class='item'><img src='admin/images/" . $row["images"] . "' alt=''></div>";

                         
    }   ?>
                                      
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- section close -->

        </div>
        <!-- content close -->

        <!-- footer begin -->
        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 sm-text-center sm-mb10">
                        <div class="mt10">&copy; Copyright 2022 - Conference by Andmbi </div>
                    </div>

                   
                </div>
            </div>

        </footer>
        <!-- footer close -->

        <a href="#" id="back-to-top"></a>
      
		
		<div id="floating-icon" class="sm-hide">
			<a href="#section-register" class="scroll-to bg-orange"><i class="fa fa-pencil"></i> Register</a>
			<span class="scroll-to bg-pink"><i class="fa fa-phone"></i> +998991775522</span>
		</div>

    </div>

    <!-- Javascript Files
    ================================================== -->
   
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/easing.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery.countTo.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/enquire.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.plugin.js"></script>
    <script src="js/jquery.countdown.js"></script>
    <script src="js/countdown-custom.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAc5d1RS_0yWJ1Hyw2hGWfbRZ9KKaxFAZo"></script>
    <script src="js/map.js"></script>
    <script src="js/designesia.js"></script>
	<script src="js/validation.js"></script>

</body>

</html>