<?php
include "../php/config.php";

  $msg = "";

  if (isset($_POST['save'])) {
  
  	$image = $_FILES['rasm']['name'];
    
  
  	$target = "../images/".basename($image);

  	$sql = "INSERT INTO gal (images) VALUES ('$image')";
 
  	mysqli_query($conn, $sql);

  	if (move_uploaded_file($_FILES['rasm']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  
  header('Location:../gal.php');
?>