<?php
include "../php/config.php";

include "php/config.php";
if(isset($_GET['id'])){
  $id=$_GET['id'];
 
  $sql = "UPDATE conference SET status='Otqazildi' WHERE id = '$id'";

  if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
  } else {
    echo "Error updating record: " . $conn->error;
  }
  
  $conn->close();
  header ("Location: ../conference1.php");
}



?>