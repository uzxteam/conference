<?php
include "../php/config.php";

  $msg = "";

  if (isset($_POST['save'])) {
  
    $uzx1 = mysqli_real_escape_string($conn, $_POST['raqam']);
      $uzx = mysqli_real_escape_string($conn, $_POST['uzx']);
  
 

  	$sql = "INSERT INTO stat (raqam,uzx) VALUES ('$uzx1','$uzx')";
 
  	mysqli_query($conn, $sql);

  	if (move_uploaded_file($_FILES['rasm']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  
  header('Location:../stat.php');
?>