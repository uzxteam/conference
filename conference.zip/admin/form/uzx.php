<?php $result = mysqli_query($conn, "SELECT * FROM banner ORDER BY id DESC LIMIT 3"  ); ?>
<?php $stat = mysqli_query($conn, "SELECT * FROM stat ORDER BY id DESC LIMIT 4"  ); ?>
<?php $spek = mysqli_query($conn, "SELECT * FROM spek ORDER BY id DESC LIMIT 4"  ); ?>
<?php $contact = mysqli_query($conn, "SELECT * FROM contact ORDER BY id DESC LIMIT 1"  ); ?>
<?php $gal = mysqli_query($conn, "SELECT * FROM gal ORDER BY id DESC LIMIT 15"  ); ?>
<?php $ham = mysqli_query($conn, "SELECT * FROM hamkor ORDER BY id DESC LIMIT 15"  ); ?>
<?php $con = mysqli_query($conn, "SELECT * FROM conference ORDER BY id DESC LIMIT 15"  ); ?>