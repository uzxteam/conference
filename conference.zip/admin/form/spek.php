<?php
include "../php/config.php";

  $msg = "";

  if (isset($_POST['save'])) {
  
  	$image = $_FILES['rasm']['name'];
      $uzx = mysqli_real_escape_string($conn, $_POST['ismi']);
      $uzx1 = mysqli_real_escape_string($conn, $_POST['lavozim']);
  
  
  	$target = "../images/".basename($image);

  	$sql = "INSERT INTO spek (images,ismi,lavozim) VALUES ('$image','$uzx','$uzx1')";
 
  	mysqli_query($conn, $sql);

  	if (move_uploaded_file($_FILES['rasm']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  
  header('Location:../spek.php');
?>