<?php
include "../php/config.php";

  $msg = "";

  if (isset($_POST['save'])) {
  
  	$image = $_FILES['rasm']['name'];
      $nomi = mysqli_real_escape_string($conn, $_POST['nomi']);
      $bosh = mysqli_real_escape_string($conn, $_POST['bosh']);
      $tug = mysqli_real_escape_string($conn, $_POST['tug']);
      $matn = mysqli_real_escape_string($conn, $_POST['matn']);
      $masul = mysqli_real_escape_string($conn, $_POST['masul']);
      $manzil = mysqli_real_escape_string($conn, $_POST['manzil']);
  
  
  
  	$target = "../images/".basename($image);

  	$sql = "INSERT INTO conference (images,nomi,bosh,tug,manzil,masul,status,matn,fayl) VALUES ('$image','$nomi','$bosh','$tug','$manzil','$masul','Otqazilmoqda','$matn','#')";
 
  	mysqli_query($conn, $sql);

  	if (move_uploaded_file($_FILES['rasm']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  
  header('Location:../conference1.php');
?>