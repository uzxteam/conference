<?php
include "../php/config.php";


if(isset($_GET['id'])){
  $id=$_GET['id'];
}
  $msg = "";

  if (isset($_POST['save'])) {
  
  	$image = $_FILES['fayl']['name'];
    
  
  	$target = "../fayl/".basename($image);

      $sql = "UPDATE conference SET fayl='$image' WHERE id = '$id'";
 
  	mysqli_query($conn, $sql);

  	if (move_uploaded_file($_FILES['fayl']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }

  header ("Location: ../conference1.php");




?>