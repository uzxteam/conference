<?php
include "../php/config.php";

  $msg = "";

  if (isset($_POST['save'])) {
  
  	$image = $_FILES['rasm']['name'];
      $uzx = mysqli_real_escape_string($conn, $_POST['uzx']);
  
  
  	$target = "../images/".basename($image);

  	$sql = "INSERT INTO banner (images,uzx) VALUES ('$image','$uzx')";
 
  	mysqli_query($conn, $sql);

  	if (move_uploaded_file($_FILES['rasm']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  
  header('Location:../banner.php');
?>