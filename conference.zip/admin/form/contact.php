<?php
include "../php/config.php";

  $msg = "";

  if (isset($_POST['save'])) {
  
  
      $uzx = mysqli_real_escape_string($conn, $_POST['manzil']);
      
      $uzx1 = mysqli_real_escape_string($conn, $_POST['nomer']);
      
      $uzx2 = mysqli_real_escape_string($conn, $_POST['email']);
  


  	$sql = "INSERT INTO contact (manzil,nomer,email) VALUES ('$uzx','$uzx1','$uzx2')";
 
  	mysqli_query($conn, $sql);

  
  }
  
  header('Location:../contact.php');
?>