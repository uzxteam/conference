<?php
include "php/config.php";
  if(isset($_GET['id'])){
    $id=$_GET['id'];
    $sql = mysqli_query($conn, "DELETE FROM banner WHERE id = '$id'");
    header ("Location: banner.php");
  }

  if(isset($_GET['con'])){
    $id=$_GET['con'];
    $sql = mysqli_query($conn, "DELETE FROM conference WHERE id = '$id'");
    header ("Location: conference1.php");
  }
  if(isset($_GET['uzx'])){
    $id=$_GET['uzx'];
    $sql = mysqli_query($conn, "DELETE FROM contact WHERE id = '$id'");
    header ("Location: contact.php");
  }

  if(isset($_GET['gal'])){
    $id=$_GET['gal'];
    $sql = mysqli_query($conn, "DELETE FROM gal WHERE id = '$id'");
    header ("Location: gal.php");
  }

  if(isset($_GET['ham'])){
    $id=$_GET['ham'];
    $sql = mysqli_query($conn, "DELETE FROM hamkor WHERE id = '$id'");
    header ("Location: hamkor.php");
  }
  if(isset($_GET['sp'])){
    $id=$_GET['sp'];
    $sql = mysqli_query($conn, "DELETE FROM spek WHERE id = '$id'");
    header ("Location: spek.php");
  }

  if(isset($_GET['st'])){
    $id=$_GET['st'];
    $sql = mysqli_query($conn, "DELETE FROM stat WHERE id = '$id'");
    header ("Location: stat.php");
  }


  ?>