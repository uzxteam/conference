<?php
include "menu.php"; ?>
		
		
		<div class="page-wrapper">
			<div class="page-content">
				
			
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase">Conference</h6>
						<hr/>
						<div class="card">
							<div class="card-body">
								<form method="POST" action="form/conference.php" enctype="multipart/form-data">
                                <h4>Rasm yuklang</h4>
									<input  type="file" name="rasm" accept=".xlsx,.xls,image/*,.doc,audio/*,.docx,video/*,.ppt,.pptx,.txt,.pdf" multiple><br>
                                    <br>
									<input class="form-control form-control-lg mb-3" name="nomi" placeholder="Nomi" aria-label=".form-control-lg example">
                                    <input class="form-control form-control-lg mb-3" name="bosh" placeholder="Boshlanish vaqti" aria-label=".form-control-lg example">
                                    <input class="form-control form-control-lg mb-3" name="tug" placeholder="Tugash vaqti" aria-label=".form-control-lg example">
                                    <input class="form-control form-control-lg mb-3" name="matn" placeholder="Conference haqida" aria-label=".form-control-lg example">
                                    <input class="form-control form-control-lg mb-3" name="masul" placeholder="Masul" aria-label=".form-control-lg example">
                                    <input class="form-control form-control-lg mb-3" name="manzil" placeholder="Manzil" aria-label=".form-control-lg example">
								    <button type="submit" name="save" class="btn btn-outline-dark px-5">Saqlash</button>
								</form> 
							</div>
						</div>
					</div>
				</div>
	
  	
  	
			</div>
		</div>
		<?php
include "pasi.php"; ?>