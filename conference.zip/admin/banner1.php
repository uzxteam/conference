<?php
include "menu.php"; ?>
		
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				
			
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase">Banner qismi</h6>
						<hr/>
						<div class="card">
							<div class="card-body">
								<form method="POST" action="form/banner.php" enctype="multipart/form-data">
									<input  type="file" name="rasm" accept=".xlsx,.xls,image/*,.doc,audio/*,.docx,video/*,.ppt,.pptx,.txt,.pdf" multiple>
									<input class="form-control form-control-lg mb-3" name="uzx" placeholder="Matn" aria-label=".form-control-lg example">
								    <button type="submit" name="save" class="btn btn-outline-dark px-5">Saqlash</button>
								</form> 
							</div>
						</div>
					</div>
				</div>
	
  	
  	
			</div>
		</div>
		<?php
include "pasi.php"; ?>