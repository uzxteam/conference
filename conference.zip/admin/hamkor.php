<?php
include "menu.php"; ?>
	<?php
include "form/uzx.php"; ?>
		
		<div class="page-wrapper">
			<div class="page-content">
				
            <?php
    while ($row = mysqli_fetch_array($ham)) {
		echo"<div class='row row-cols-1 row-cols-md-2 row-cols-xl-4'>";
		echo"<div class='col'>";
		echo"<div class='card radius-10 border-start border-0 border-3 border-info'>";
		echo"<div class='card-body'>";
		echo"<div class='d-flex align-items-center'>";
       echo"<div>";
      	echo "<img width='200px'  src='images/".$row['images']."' >";
		 
      echo "	<a type='button' class='btn btn-outline-danger px-5 radius-30' href='dele.php?ham=" . $row["id"] . "'>O'chirish<a/> ";
      echo"	</div>";
	  echo"	</div>";
	  echo"	</div>";
	  echo"	</div>";
      echo"	</div>";
      echo"	</div>";
    }
  ?>
				  
				  </div> 
				</div><!--end row-->

			

			</div>
		</div>
		<?php
include "pasi.php"; ?>