<?php
include "php/config.php";


if(isset($_GET['id'])){
  $id=$_GET['id'];


}



?><?php
include "menu.php"; ?>
		
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				
			
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase">Fayl qismi</h6>
						<hr/>
						<div class="card">
							<div class="card-body">
							<?php	echo "<form method='POST' action='form/fayl.php?id=$id' enctype='multipart/form-data'>";
								echo "	<input  type='file' name='fayl'  multiple>";
								echo "<button type='submit' name='save' class='btn btn-outline-dark px-5'>Saqlash</button>";	
								 echo "</form>";   
								 ?>
							</div>
						</div>
					</div>
				</div>
	
  	
  	
			</div>
		</div>
		<?php
include "pasi.php"; ?>