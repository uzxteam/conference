<?php
include "menu.php"; ?>
	<?php
include "form/uzx.php"; ?>
		
		<div class="page-wrapper">
			<div class="page-content">
				<div class="row row-cols-1 row-cols-md-2 row-cols-xl-4">
                   <div class="col">
					 <div class="card radius-10 border-start border-0 border-3 border-info">
						<div class="card-body">
							<div class="d-flex align-items-center">
								<div> <?php
    while ($row = mysqli_fetch_array($contact)) {
    
      	echo "<h3>Manzil </h3> <h6>".$row['manzil']."</h6>";
		  echo "<h3>Telefon</h3> <h6> ".$row['nomer']."</h6>";
          echo "<h3>Email </h3> <h6>".$row['email']."</h6>";
      echo "	<a type='button' class='btn btn-outline-danger px-5 radius-30' href='dele.php?uzx=" . $row["id"] . "'>O'chirish<a/> ";
      
    }
  ?>
								
								</div>
								
							</div>
						</div>
					 </div>
				   </div>
				  
				  </div> 
				</div><!--end row-->

			

			</div>
		</div>
		<?php
include "pasi.php"; ?>