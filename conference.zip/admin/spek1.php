<?php
include "menu.php"; ?>
		
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				
			
				<div class="row">
					<div class="col-xl-9 mx-auto">
						<h6 class="mb-0 text-uppercase">Rasm yuklash</h6>
						<hr/>
						<div class="card">
							<div class="card-body">
								<form method="POST" action="form/spek.php" enctype="multipart/form-data">
									<input  type="file" name="rasm" accept=".xlsx,.xls,image/*,.doc,audio/*,.docx,video/*,.ppt,.pptx,.txt,.pdf" multiple>
									<input class="form-control form-control-lg mb-3" name="ismi" placeholder="ismi" aria-label=".form-control-lg example">
                                    <input class="form-control form-control-lg mb-3" name="lavozim" placeholder="lavozimi" aria-label=".form-control-lg example">
								    <button type="submit" name="save" class="btn btn-outline-dark px-5">Saqlash</button>
								</form> 
							</div>
						</div>
					</div>
				</div>
	
  	
  	
			</div>
		</div>
		<?php
include "pasi.php"; ?>