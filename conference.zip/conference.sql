-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 18, 2022 at 02:11 PM
-- Server version: 8.0.24
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `conference`
--

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int NOT NULL,
  `images` text NOT NULL,
  `uzx` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `images`, `uzx`) VALUES
(3, 'download.jfif', 'aas');

-- --------------------------------------------------------

--
-- Table structure for table `conference`
--

CREATE TABLE `conference` (
  `id` int NOT NULL,
  `images` text NOT NULL,
  `nomi` text NOT NULL,
  `bosh` text NOT NULL,
  `tug` text NOT NULL,
  `manzil` text NOT NULL,
  `masul` text NOT NULL,
  `status` text NOT NULL,
  `matn` text NOT NULL,
  `fayl` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `conference`
--

INSERT INTO `conference` (`id`, `images`, `nomi`, `bosh`, `tug`, `manzil`, `masul`, `status`, `matn`, `fayl`) VALUES
(2, 'photo_2021-06-15_07-00-02.jpg', 'Andijon Mashinasozlik insituti haqida boladiga bir balo birbalo', '27-fevral', '28-aprel', 'Andijan', 'Uzxteam', 'Otqazildi', 'Andijon Mashinasozlik insituti haqida boladiga bir balo birbalo Andijon Mashinasozlik insituti haqida boladiga bir balo birbalo', 'view-source_market.meteors.agency_Evanto_en_Events_vr-rock-concert-of-the-gloria.html');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int NOT NULL,
  `manzil` text NOT NULL,
  `nomer` text NOT NULL,
  `email` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `manzil`, `nomer`, `email`) VALUES
(1, 'Andijan', '+998907874867', 'uzxtemurmalik@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `gal`
--

CREATE TABLE `gal` (
  `id` int NOT NULL,
  `images` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `gal`
--

INSERT INTO `gal` (`id`, `images`) VALUES
(1, 'photo_2021-06-15_07-00-02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `hamkor`
--

CREATE TABLE `hamkor` (
  `id` int NOT NULL,
  `images` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `hamkor`
--

INSERT INTO `hamkor` (`id`, `images`) VALUES
(5, 'Group 1 (1).png'),
(7, 'photo_2021-06-15_07-00-02.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `spek`
--

CREATE TABLE `spek` (
  `id` int NOT NULL,
  `images` text NOT NULL,
  `ismi` text NOT NULL,
  `lavozim` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `spek`
--

INSERT INTO `spek` (`id`, `images`, `ismi`, `lavozim`) VALUES
(1, 'photo_2021-06-15_07-00-02.jpg', 'Temurmalik', 'Kontent menenjer');

-- --------------------------------------------------------

--
-- Table structure for table `stat`
--

CREATE TABLE `stat` (
  `id` int NOT NULL,
  `raqam` text NOT NULL,
  `uzx` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `stat`
--

INSERT INTO `stat` (`id`, `raqam`, `uzx`) VALUES
(1, '244', 'uzxteam');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `unique_id` int NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `unique_id`, `fname`, `lname`, `email`, `password`, `img`, `status`) VALUES
(1, 1525673840, 'temur', 'malik', 'admin@andmbi.uz', '1ba2656880fb6cb03891142158433b39', '1633055872WIN_20210922_06_17_22_Pro.jpg', 'Active now');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `conference`
--
ALTER TABLE `conference`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gal`
--
ALTER TABLE `gal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hamkor`
--
ALTER TABLE `hamkor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `spek`
--
ALTER TABLE `spek`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stat`
--
ALTER TABLE `stat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `conference`
--
ALTER TABLE `conference`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gal`
--
ALTER TABLE `gal`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hamkor`
--
ALTER TABLE `hamkor`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `spek`
--
ALTER TABLE `spek`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `stat`
--
ALTER TABLE `stat`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
